package Growwx.Growwx_rsrc;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class searchProduct extends BaseGrowx 
{
    WebDriver driver;

    @Test
    public void SearchProduct() throws IOException, InterruptedException 
    {
        driver = initlizeDriver();
        loginApplication();    
    }
}

