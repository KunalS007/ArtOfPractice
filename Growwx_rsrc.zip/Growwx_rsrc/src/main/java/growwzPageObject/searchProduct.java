package growwzPageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Growwx.Growwx_rsrc.BaseGrowx;


public class searchProduct extends BaseGrowx
{
	By productSearch = By.xpath("//button[@id='remove-sauce-labs-backpack']");
	
	public searchProduct (WebDriver driver)
	{
		this.driver = driver;
	}
	
	public WebElement searchProducts()
	{
		return driver.findElement(productSearch);	
	}
}
